import requests
import pandas as pd
import numpy as np
import streamlit as st
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from datetime import datetime, timedelta
import yfinance as yf

# Alpha Vantage API configuration
API_KEY = 'PO82U453G2FVWNTG'
BASE_URL = 'https://www.alphavantage.co/query'

# Function to fetch XAU/USD data from Alpha Vantage or fallback to GLD from Yahoo Finance

def fetch_xauusd_data():
    try:
        params = {
            'function': 'FX_INTRADAY',
            'from_symbol': 'XAU',
            'to_symbol': 'USD',
            'interval': '5min',
            'apikey': API_KEY,
            'outputsize': 'compact'
        }
        response = requests.get(BASE_URL, params=params)
        data = response.json()

        if 'Time Series FX (5min)' not in data:
            raise ValueError("Alpha Vantage data unavailable.")

        df = pd.DataFrame.from_dict(data['Time Series FX (5min)'], orient='index')
        df = df.rename(columns={
            '1. open': 'Open',
            '2. high': 'High',
            '3. low': 'Low',
            '4. close': 'Close'
        })
        df.index = pd.to_datetime(df.index)
        df = df.sort_index()
        df = df.astype(float)
        st.success("Using data from Alpha Vantage (XAU/USD)")
        return df[['Close']]
    except:
        st.warning("Alpha Vantage failed. Using Yahoo Finance (GLD) as fallback.")
        data = yf.download("GLD", period="5d", interval="5m")
        data = data[['Close']].dropna()
        if not data.empty:
            st.success("Using data from Yahoo Finance (GLD)")
        return data if not data.empty else None

# Streamlit configuration
st.set_page_config(page_title="Gold Price Predictor", layout="wide")
st.title("📈 Gold Price Predictor (Next 10 Minutes)")

# Auto-refresh every 5 minutes
st.experimental_set_query_params(auto_refresh=str(datetime.now()))
st_autorefresh = st.empty()
st_autorefresh.info("Refreshing every 5 minutes...")
st_autorefresh.empty()

# Fetch and display data
data = fetch_xauusd_data()
if data is not None and len(data) > 70:
    st.subheader("📅 Recent Gold Price Data")
    st.line_chart(data[-60:])

    # Prepare data for LSTM
    scaler = MinMaxScaler()
    scaled_data = scaler.fit_transform(data)
    window_size = 60
    X, y = [], []
    for i in range(window_size, len(scaled_data) - 10):
        X.append(scaled_data[i - window_size:i, 0])
        y.append(scaled_data[i:i + 10, 0])
    X = np.array(X)
    y = np.array(y)
    X = X.reshape((X.shape[0], X.shape[1], 1))

    # Train LSTM model
    st.text("🔄 Training model...")
    model = Sequential([
        LSTM(50, return_sequences=True, input_shape=(X.shape[1], 1)),
        LSTM(50),
        Dense(10)
    ])
    model.compile(optimizer='adam', loss='mean_squared_error')
    model.fit(X, y, epochs=5, batch_size=32, verbose=0)

    # Predict next 10 minutes
    latest_seq = scaled_data[-window_size:].reshape(1, window_size, 1)
    pred_scaled = model.predict(latest_seq)
    pred_prices = scaler.inverse_transform(pred_scaled).flatten()

    # Future timestamps
    last_time = data.index[-1]
    future_times = [last_time + timedelta(minutes=i + 1) for i in range(10)]

    # Plot
    st.subheader("📊 Prediction vs Actual")
    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(data.index[-60:], data['Close'].values[-60:], label='Last 60 min Actual')
    ax.plot(future_times, pred_prices, '--o', label='Next 10 min Prediction')
    ax.set_xlabel("Time")
    ax.set_ylabel("Price (USD)")
    ax.set_title("Gold Price Forecast (XAU/USD or GLD)")
    ax.legend()
    ax.grid(True)
    st.pyplot(fig)

    # Show table
    st.subheader("📊 Predicted Prices (Next 10 min)")
    pred_df = pd.DataFrame({"Time": future_times, "Predicted Price": pred_prices})
    st.dataframe(pred_df.set_index("Time"))
else:
    st.warning("Not enough data to make predictions. Please try again in a few minutes.")
